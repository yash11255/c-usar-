#include<iostream>

using namespace std;

int main() {
 
	cout << "sizeof(int) : " << sizeof(int) << 'B' << endl;
	cout << "sizeof(float) : " << sizeof(float) << 'B' << endl;
	cout << "sizeof(double) : " << sizeof(double) << 'B' << endl;
	cout << "sizeof(char) : " << sizeof(char) << 'B' << endl;
	cout << "sizeof(bool) : " << sizeof(bool) << 'B' << endl;

	return 0;
}