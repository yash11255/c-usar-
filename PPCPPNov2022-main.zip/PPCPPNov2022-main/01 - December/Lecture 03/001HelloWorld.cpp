#include<iostream>

using namespace std;

int main() {

	/*

	cout << "Hello World";
	cout << '\n';
	cout << 2;
	cout << '\n';
	cout << 'x';
	cout << endl;
	cout << 1+2;
	cout << endl;
	cout << 3.14;
	
	*/

	// I am printing values using cout statement

	cout << "Hello World" << '\n' 
	     << 2 << '\n' 
	     << 'x' << endl 
	     << 1+2 << endl 
	     << 3.14;
 
	return 0;
}