#include<iostream>

using namespace std;

int main() {

	// int x; // variable declaration

	// cout << "enter an integer :" ;

	// cin >> x;

	// cout << "you've entered x = " << x << endl;

	// float y;

	// cout << "enter a floating point number : ";

	// cin >> y;

	// cout << "you've entered y = " << y << endl;


	int x;
	float y;

	cout << "enter an integer and a floating point number : ";

	cin >> x >> y;

	cout << "you've entered x = " << x << " y = " << y << endl;

	return 0;
}