#include<iostream>

using namespace std;

int main() {

	int x;

	x = 100;

	float y;

	y = 3.14;

	double z;

	z = 12.24 + 12.76;

	cout << "x = " << x << " y = " << y << " z = " << z << endl;


	// int x1;
	// int x2;
	// int x3;

	int x1, x2, x3;

	x1 = 1;
	x2 = 2;
	x3 = 3;

	cout << "x1 = " << x1 << " x2 = " << x2 << " x3 = " << x3 << endl;


	return 0;
}