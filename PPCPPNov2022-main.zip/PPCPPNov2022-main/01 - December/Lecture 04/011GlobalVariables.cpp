#include<iostream>

using namespace std;

int x = 100; // global variable

int main() {

	cout << x << endl;
	
	return 0;
}