#include<iostream>

using namespace std;

int main() {

	cout << "true && true : " << (true && true) << endl;
	cout << "true && false : " << (true && false) << endl;
	cout << "false && true : " << (false and true) << endl;
	cout << "false && false : " << (false and false) << endl;

	cout << endl;

	cout << "true || true : " << (true || true) << endl;
	cout << "true || false : " << (true || false) << endl;
	cout << "false or true : " << (false or true) << endl;
	cout << "false or false : " << (false or false) << endl;

	cout << endl;

	cout << "!true : " << (!true) << endl;
	cout << "!false : " << (!false) << endl;

	return 0;
}