#include<iostream>

#define PI 3.14
#define SEMICOLON ;
#define PRINT cout 
// #define F for(int i=0; i<5; i++) {cout << i << " ";}
#define F(n) for(int i=0; i<n; i++) {cout << i << " ";}

using namespace std;

int main() {

	// PRINT << PI << endl SEMICOLON

	// F
	
	int n;
	cin >> n;

	F(n)

	return 0;
}