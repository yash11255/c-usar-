#include<iostream>

using namespace std;

int main() {

	int x = 0;

	x++; // or ++x

	cout << "x : " << x << endl;

	int y = 1;

	y--; // or --y

	cout << "y : " << y << endl;
	
	return 0;
}