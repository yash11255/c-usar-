#include<iostream>

using namespace std;

int main() {

	int n ;
	cin >> n;
	
	int i = 0;

	do {
		cout << i << " ";
		i++;
	} while(i < n);

	cout << endl;
	
	return 0;
}