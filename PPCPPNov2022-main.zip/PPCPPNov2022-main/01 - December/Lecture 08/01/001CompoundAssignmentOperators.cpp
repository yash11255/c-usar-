#include<iostream>

using namespace std;

int main() {

	int a = 5;
	int b = 3;

	// a = a+b;

	// a += b;

	a *= b-1;

	cout << a << endl;
	
	return 0;
}