#include<iostream>
#include<algorithm>

using namespace std;

int main() {

	int arr[] = {54, 546, 548, 60};
	int n = sizeof(arr) / sizeof(int);

	// todo ...

	return 0;
}