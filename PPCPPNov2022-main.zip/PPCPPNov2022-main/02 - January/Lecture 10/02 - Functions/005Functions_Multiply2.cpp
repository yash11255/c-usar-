#include<iostream>

using namespace std;

// int multiply(int a, int b) {
// 	return a*b;
// }


int multiply(int x, int y) {
	return x*y;
}

int main() {

	int x = 2;
	int y = 3;

	cout << multiply(x, y) << endl;
	
	return 0;
}